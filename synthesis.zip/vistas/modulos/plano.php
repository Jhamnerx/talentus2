<div class="content-wrapper">

  <section class="content-header">

   <h1>
      JARDINES DE HUANCHACO
    </h1>

    <ol class="breadcrumb">

      <li><a href="inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      <li><a href="almacen"><i class="fa fa-laptop"></i> Almacen</a></li>

      <li class="active">Gestor Categorias</li>

    </ol>

  </section>

  <section class="content">
    <table class="prima" border="2" style="width: 25%; text-align: center; vertical-align: center; height: 30%; background-color: #2555f5; border-color: black; font-weight: 600; color: black">
      <tr class="rowPrima">
        
        <td class="columnaPrima val1">1</td>
        <td rowspan="2" class="columnaPrima val2">2</td>
        <td rowspan="2" class="columnaPrima val3">3</td>
        <td rowspan="2" class="columnaPrima val4">4</td>
        <td class="columnaPrima val5">5</td>

      </tr>

      <tr class="rowPrima">

        <td class="columnaPrima val16">16</td>
        <td class="columnaPrima val6">6</td>
        

      </tr>

      <tr class="rowPrima">
        <td class="columnaPrima val15">15</td>
        <td class="columnaPrima valA" colspan="3">A'</td>
        <td class="columnaPrima val7">7</td>

      </tr>

      <tr class="rowPrima">
        <td class="columnaPrima val14">14</td>
        <td class="columnaPrima val12" rowspan="2">12</td>
        <td class="columnaPrima val11" rowspan="2">11</td>
        <td class="columnaPrima val10" rowspan="2">10</td>
        <td class="columnaPrima val8">8</td>
      </tr>

      <tr class="rowPrima">
        <td class="columnaPrima val13">13</td>
        <td class="columnaPrima val9">9</td>
      </tr>

    </table>


  </section>

</div>


<script type="text/javascript">
  





</script>

