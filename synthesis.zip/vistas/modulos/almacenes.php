<div class="content-wrapper">

  <!-- content-header -->
  <section class="content-header">
    
    <h1>
    Almacenes
    <small>Panel de Almancees</small>
    </h1>

    <ol class="breadcrumb">

      <li><a href="inicio"><i class="fa fa-dashboard"></i> Inicio</a></li>
      <li class="active">Almacenes</li>

    </ol>

  </section>
  <!-- content-header -->

  <!-- content -->
  <section class="content">
    
    <!-- row -->

    <div class="container-centro" style="padding: 60 160 60 100;"> 
      <div class="row">

         <?php


          include "almacenes/almacenes.php";

        
        ?>



      </div>
    </div>
    <!-- row -->

 </section>
  <!-- content -->

</div>
<!-- content-wrapper -->