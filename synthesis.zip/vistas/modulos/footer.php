 <!-- main-footer -->
<footer class="main-footer">

<strong>Copyright &copy; 2019 <a href="#">Js Development</a>.</strong> Todos los derechos reservados.

</footer>
<!-- main-footer -->